package com.github.davidmoten.bigsorter;

public class QueryMain {
    
    public static void main(String[] args) {
        
    }

}
